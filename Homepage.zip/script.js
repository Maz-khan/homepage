//function myFunction(a,b){
 //   return a*b;
//}

//console.log(myFunction(3,4));

// let x=myFunction(4,3);

// function myFunction(a,b){
//     return a*b;
// }

// console.log(x);


function toCelsius(fahrenheit){
    return (5/9)*(fahrenheit-32);
}

console.log(toCelsius(98.2));

